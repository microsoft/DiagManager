#!/bin/bash
tar --exclude='./.git' -cvf pssdiag.tar .
