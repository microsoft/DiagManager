-- this stored procedure is created from MSDiagprocs.sql
-- please make sure that script runs before launching this
-- this trace will capture events that correspond to general performance template. See the Events parameter.

EXEC tempdb.dbo.sp_trace13 'ON'
,@Events='138,161,140,160,196,78,74,76,53,70,75,77,92,94,167,93,95,16,193,212,137,214,21,33,127,67,55,79,80,69,162,157,148,60,189,61,58,217,218,190,115,158,159,116,14,20,15,18,195,81,150,17,216,215,100,10,11,182,186,184,188,187,192,71,12,13,166,73'
,@AppName='SQLDIAG_Trace_*'
,@FileName='/tmp/pssdiag/output/sbk-vm1-rhel74_pssdiag_trace'
,@MaxFileSize=5
,@FileCount=10

